Controls:

Use the mouse for the menus
KBM:
Arrow keys to move
Space to fire
A/S for special

Controller:
left thumbstick to move
X to fire
Y for special

There is no pause button